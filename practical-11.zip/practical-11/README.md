# Practical 11 - Floyd-Warshall Algorithm

## Aim

To implement the Floyd-Warshall Algorithm in Python to find the shortest paths between all pairs of vertices in a weighted graph.

## Theory

The Floyd-Warshall Algorithm is a dynamic programming algorithm used to find the shortest paths between every pair of vertices in a weighted graph. It works by considering each vertex as an intermediate vertex and updating the shortest distances.

## Requirements

- Python 3.x

## Input

- Number of vertices
- Adjacency matrix of the graph
- Enter each row as space-separated values.
- Use **99999** to represent no direct edge.

Example:
```
0 5 99999 10
```

## Output

- Shortest distance matrix showing the minimum distance between every pair of vertices.

## Algorithm

1. Read the number of vertices.
2. Read the adjacency matrix.
3. Copy the matrix into a distance matrix.
4. Consider each vertex as an intermediate vertex.
5. Update the shortest distance between every pair of vertices.
6. Display the final shortest distance matrix.

## Summary

This program reads a weighted graph from the user and applies the Floyd-Warshall Algorithm to compute the shortest paths between all pairs of vertices. The final distance matrix is displayed.

## Conclusion

The Floyd-Warshall Algorithm efficiently computes the shortest paths between every pair of vertices using dynamic programming. The program successfully displays the minimum distances between all vertices.