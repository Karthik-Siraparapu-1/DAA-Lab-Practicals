# Practical-5: 0/1 Knapsack Problem using Dynamic Programming

## Aim
To implement the **0/1 Knapsack Problem** using the **Dynamic Programming** technique in Python and determine the maximum profit that can be obtained without exceeding the given knapsack capacity.

## Summary
In this practical, the 0/1 Knapsack Problem is solved using Dynamic Programming. The program accepts the number of items, their weights and values, and the knapsack capacity from the user. A Dynamic Programming (DP) table is created to calculate the maximum achievable profit for every possible capacity. After computing the optimal solution, the program identifies the selected items, displays their details, measures the execution time, and prints the time and space complexities.

## Algorithm
1. Read the number of items.
2. Input the weight and value of each item.
3. Input the knapsack capacity.
4. Create a DP table of size `(n + 1) × (capacity + 1)`.
5. Fill the table using the Dynamic Programming recurrence relation.
6. Find the maximum profit from the DP table.
7. Backtrack through the table to identify the selected items.
8. Display the maximum profit, selected items, execution time, and complexity.

## Time Complexity
**O(n × W)**

Where:
- `n` = Number of items
- `W` = Knapsack capacity

## Space Complexity
**O(n × W)**

## Conclusion
The 0/1 Knapsack Problem was successfully implemented using Dynamic Programming in Python. The approach efficiently computes the maximum possible profit while satisfying the weight constraint. The practical demonstrates how Dynamic Programming avoids redundant calculations by storing intermediate results, making it much more efficient than the recursive approach for this problem.