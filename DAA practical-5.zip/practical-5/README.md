# Practical-5: 0/1 Knapsack Problem using Dynamic Programming

## Aim
To implement the **0/1 Knapsack Problem** using the **Dynamic Programming** technique in Python and determine the maximum profit without exceeding the given knapsack capacity.

## Summary
In this practical, the 0/1 Knapsack Problem is implemented using Dynamic Programming. The program accepts the number of items, their weights and values, and the knapsack capacity from the user. It calculates the maximum profit, identifies the selected items, displays their details, and measures the execution time.

## Algorithm
1. Read the number of items.
2. Input the weight and value of each item.
3. Input the knapsack capacity.
4. Create a Dynamic Programming table.
5. Compute the maximum profit for each possible capacity.
6. Backtrack to find the selected items.
7. Display the maximum profit, selected items, and execution time.

## Conclusion
The 0/1 Knapsack Problem was successfully implemented using Dynamic Programming in Python. The program efficiently finds the optimal set of items that maximizes the total profit without exceeding the knapsack capacity. This practical demonstrates the effectiveness of Dynamic Programming in solving optimization problems.