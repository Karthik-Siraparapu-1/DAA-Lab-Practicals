# Practical 9 - Prim's Algorithm

## Aim

To implement Prim's Algorithm in Python to find the Minimum Spanning Tree (MST) of a weighted graph.

## Theory

Prim's Algorithm is a greedy algorithm used to construct the Minimum Spanning Tree of a connected weighted graph. It starts from any one vertex and repeatedly selects the minimum-weight edge that connects a visited vertex to an unvisited vertex until all vertices are included.

## Requirements

- Python 3.x

## Input

- Number of vertices
- Adjacency matrix of the graph
- Enter 0 where there is no edge.

## Output

- Adjacency matrix
- Edges of the Minimum Spanning Tree
- Total minimum cost

## Algorithm

1. Read the number of vertices.
2. Read the adjacency matrix.
3. Select the first vertex as the starting vertex.
4. Find the minimum-weight edge connecting a selected vertex to an unselected vertex.
5. Add the selected edge to the Minimum Spanning Tree.
6. Repeat until all vertices are included.
7. Display the selected edges and total minimum cost.

## Summary

This program reads a weighted graph from the user and uses Prim's Algorithm to construct the Minimum Spanning Tree. It displays the selected edges and calculates the total minimum cost.

## Conclusion

Prim's Algorithm efficiently finds the Minimum Spanning Tree of a connected weighted graph by selecting the minimum-cost edge at each step. The program successfully generates the MST and its total cost.