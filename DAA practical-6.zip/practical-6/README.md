# Practical-6: Matrix Chain Multiplication using Dynamic Programming

## Aim
To implement **Matrix Chain Multiplication** using the **Dynamic Programming** technique in Python and determine the minimum number of scalar multiplications required to multiply a chain of matrices.

## Summary
In this practical, Matrix Chain Multiplication is solved using Dynamic Programming. The program accepts the number of matrices and their dimensions from the user. It computes the minimum number of scalar multiplications required to multiply the matrices efficiently and displays the optimal parenthesization along with the execution time.

## Algorithm
1. Read the number of matrices.
2. Input the dimensions of the matrices.
3. Create Dynamic Programming tables to store the minimum multiplication cost and optimal split positions.
4. Compute the minimum multiplication cost for all possible matrix chains.
5. Determine the optimal parenthesization.
6. Display the minimum multiplication cost, optimal parenthesization, and execution time.

## Conclusion
The Matrix Chain Multiplication problem was successfully implemented using Dynamic Programming in Python. The algorithm efficiently determines the optimal order of matrix multiplication, reducing the total number of scalar multiplications. This practical demonstrates how Dynamic Programming improves efficiency by storing intermediate results and avoiding repeated calculations.