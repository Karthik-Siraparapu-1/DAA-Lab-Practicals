import time

# User Input
n = int(input("Enter the number of elements: "))
arr = []

print("Enter the elements:")
for i in range(n):
    arr.append(int(input()))

key = int(input("Enter the element to search: "))

# Start Execution Time
start_time = time.perf_counter()

found = False
position = -1
comparisons = 0

# Linear Search
for i in range(n):
    comparisons += 1
    if arr[i] == key:
        found = True
        position = i
        break

# End Execution Time
end_time = time.perf_counter()

# Output
print("\n----- Linear Search Result -----")

if found:
    print(f"Element {key} found at position {position + 1}")
else:
    print(f"Element {key} not found")

print(f"Comparisons Made : {comparisons}")
print(f"Execution Time   : {(end_time - start_time):.10f} seconds")

# Current Execution Time Complexity
print("\nCurrent Execution Time Complexity:")
if comparisons == 1:
    print("O(1) - Best Case")
elif found:
    print("O(n) - Average Case")
else:
    print("O(n) - Worst Case")

# General Time Complexities
print("\nGeneral Time Complexities:")
print("Best Case    : O(1)")
print("Average Case : O(n)")
print("Worst Case   : O(n)")

# Space Complexity
print("\nSpace Complexity:")
print("O(1)")