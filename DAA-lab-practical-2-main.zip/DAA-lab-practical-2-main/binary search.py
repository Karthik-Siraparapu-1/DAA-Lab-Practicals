import time

# User Input
n = int(input("Enter the number of elements: "))

arr = []

print("Enter the elements:")
for i in range(n):
    arr.append(int(input()))

key = int(input("Enter the element to search: "))

# Sort the array
arr.sort()

# Start time
start_time = time.perf_counter()

low = 0
high = n - 1
position = -1
comparisons = 0

# Binary Search
while low <= high:

    comparisons += 1
    mid = (low + high) // 2

    if arr[mid] == key:
        position = mid
        break

    elif arr[mid] < key:
        low = mid + 1

    else:
        high = mid - 1

# End time
end_time = time.perf_counter()

# Output
print("\nSorted Array:", arr)

print("\n----- Binary Search Result -----")

if position != -1:
    print(f"Element {key} found at position {position + 1}")
else:
    print(f"Element {key} not found")

print(f"Comparisons Made : {comparisons}")
print(f"Execution Time   : {(end_time - start_time):.10f} seconds")

print("\nCurrent Execution Time Complexity:")

if comparisons == 1:
    print("O(1) - Best Case")
elif position != -1:
    print("O(log n) - Average Case")
else:
    print("O(log n) - Worst Case")

print("\nGeneral Time Complexities:")
print("Best Case    : O(1)")
print("Average Case : O(log n)")
print("Worst Case   : O(log n)")

print("\nSpace Complexity:")
print("O(1)")