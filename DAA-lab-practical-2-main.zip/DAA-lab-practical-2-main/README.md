# DAA Practical 2: Linear Search and Binary Search

## Overview

This repository contains Python implementations of two searching algorithms:

1. Linear Search
2. Binary Search

The programs allow the user to:

- Enter array elements.
- Search for a specific element.
- Display the position of the element.
- Count the number of comparisons.
- Measure execution time.
- Display current execution time complexity.
- Display general time complexities.
- Display space complexity.

---

# 1. Linear Search

## Description

Linear Search checks each element of the array one by one until the required element is found or the end of the array is reached.

## Algorithm

1. Read the number of elements.
2. Read the array elements.
3. Read the element to search.
4. Traverse the array sequentially.
5. Compare each element with the search key.
6. If the element is found, display its position.
7. Display the number of comparisons and execution time.

## Time Complexity

- Best Case: O(1)
- Average Case: O(n)
- Worst Case: O(n)

## Space Complexity

- O(1)

---

# 2. Binary Search

## Description

Binary Search works only on sorted arrays. It repeatedly divides the search space into two halves until the element is found or the search space becomes empty.

## Algorithm

1. Read the number of elements.
2. Read the array elements.
3. Read the element to search.
4. Sort the array.
5. Find the middle element.
6. Compare the middle element with the search key.
7. Search the left or right half accordingly.
8. Display the result, comparisons, and execution time.

## Time Complexity (Binary Search Only)

- Best Case: O(1)
- Average Case: O(log n)
- Worst Case: O(log n)

## Overall Complexity (Including Sorting)

- Sorting: O(n log n)
- Binary Search: O(log n)
- Total Complexity: O(n log n)

## Space Complexity

- O(1)

---

# Features

- User input support
- Comparison counting
- Execution time measurement
- Current execution complexity display
- General time complexity display
- Space complexity display
- Automatic sorting for Binary Search

---

# Technologies Used

- Python 3
- `time.perf_counter()`

---

# Summary

This project demonstrates the implementation of Linear Search and Binary Search algorithms in Python. It analyzes the performance of both algorithms by counting the number of comparisons, measuring execution time, and displaying their time and space complexities.

Linear Search can be used on both sorted and unsorted arrays, whereas Binary Search requires the array to be sorted before searching.

---

# Conclusion

Linear Search is simple and easy to implement, but its time complexity is O(n), making it less efficient for large datasets.

Binary Search is more efficient, with a time complexity of O(log n), because it repeatedly divides the search space into two halves. Therefore, Binary Search is generally preferred for searching in large sorted datasets.
