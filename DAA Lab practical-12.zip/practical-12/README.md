# Practical 12 - Travelling Salesman Problem

## Aim

To implement the Travelling Salesman Problem (TSP) in Python using the brute-force approach.

## Theory

The Travelling Salesman Problem (TSP) is a well-known optimization problem. The objective is to find the shortest possible route that visits every city exactly once and returns to the starting city.

In this program, all possible paths are generated using permutations, and the path with the minimum total cost is selected.

## Requirements

- Python 3.x

## Input

- Number of cities
- Cost matrix
- Enter each row as space-separated values.

Example:
```
0 10 15 20
```

## Output

- Minimum travelling cost
- Best travelling path

## Algorithm

1. Read the number of cities.
2. Read the cost matrix.
3. Generate all possible routes using permutations.
4. Calculate the total cost of each route.
5. Compare the costs and store the minimum cost.
6. Display the minimum cost and the best path.

## Summary

This program accepts a cost matrix from the user and solves the Travelling Salesman Problem using the brute-force method. It evaluates every possible route and selects the one with the minimum travelling cost.

## Conclusion

The brute-force approach guarantees the optimal solution for the Travelling Salesman Problem by checking every possible route. It is suitable for small numbers of cities but becomes computationally expensive for larger graphs.