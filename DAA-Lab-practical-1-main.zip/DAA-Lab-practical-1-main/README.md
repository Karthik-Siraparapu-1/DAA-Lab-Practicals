# Sorting Algorithms in Python

## Overview

This repository contains the Python implementation of five fundamental sorting algorithms. Each program accepts user input, sorts the given array, measures execution time, and displays the theoretical time and space complexities.

These implementations are designed for learning Data Structures and Algorithms (DSA), practical laboratory exercises, and viva preparation.

---

## Sorting Algorithms Included

1. Bubble Sort
2. Selection Sort
3. Insertion Sort
4. Quick Sort
5. Merge Sort

---

## Algorithm Summary

### Bubble Sort
Bubble Sort repeatedly compares adjacent elements and swaps them if they are in the wrong order. After each pass, the largest element moves to its correct position.

**Time Complexity**
- Best Case: O(n)
- Average Case: O(n²)
- Worst Case: O(n²)

**Space Complexity**
- O(1)

---

### Selection Sort
Selection Sort repeatedly finds the smallest element from the unsorted portion of the array and places it in its correct position.

**Time Complexity**
- Best Case: O(n²)
- Average Case: O(n²)
- Worst Case: O(n²)

**Space Complexity**
- O(1)

---

### Insertion Sort
Insertion Sort builds the sorted array one element at a time by inserting each element into its proper position in the already sorted portion.

**Time Complexity**
- Best Case: O(n)
- Average Case: O(n²)
- Worst Case: O(n²)

**Space Complexity**
- O(1)

---

### Quick Sort
Quick Sort is a Divide and Conquer algorithm that selects a pivot element, partitions the array into smaller and larger elements, and recursively sorts the partitions.

**Time Complexity**
- Best Case: O(n log n)
- Average Case: O(n log n)
- Worst Case: O(n²)

**Space Complexity**
- Average Case: O(log n)
- Worst Case: O(n)

---

### Merge Sort
Merge Sort divides the array into two halves, recursively sorts each half, and merges the sorted halves into a single sorted array.

**Time Complexity**
- Best Case: O(n log n)
- Average Case: O(n log n)
- Worst Case: O(n log n)

**Space Complexity**
- O(n)


---

## Features

- Python implementation of five sorting algorithms.
- Accepts user input.
- Displays the sorted output.
- Measures execution time using `time.perf_counter()`.
- Prints theoretical time complexity.
- Prints theoretical space complexity.
- Easy to understand and beginner-friendly.
- Suitable for DSA practicals, assignments, and viva examinations.

---

## Summary

This project demonstrates the implementation of five widely used sorting algorithms in Python. Each algorithm follows a different approach to sorting data and has its own advantages and limitations. Bubble Sort, Selection Sort, and Insertion Sort are simple comparison-based algorithms that are suitable for understanding the fundamentals of sorting. Quick Sort and Merge Sort use the Divide and Conquer technique, making them more efficient for larger datasets. The programs also display execution time and theoretical complexities, helping users understand both practical performance and algorithmic analysis.

---

## Conclusion

Sorting is one of the most fundamental concepts in Data Structures and Algorithms. Understanding how different sorting algorithms work, along with their time and space complexities, helps in selecting the most appropriate algorithm for different applications. This repository provides clear Python implementations that serve as a strong foundation for learning algorithm design, complexity analysis, and practical programming.

---

## Author

**KARTHIK SIRAPARAPU**

B.Tech Computer Science and Engineering (AI & ML)

Marwadi University
