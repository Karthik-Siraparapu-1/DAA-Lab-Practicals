# Practical 7: Implementation of Making Change Problem Using Dynamic Programming

## Aim
To implement the Making Change problem using Dynamic Programming and analyze its execution time, time complexity, and space complexity.

## Summary
- The program finds the minimum number of coins required to make a given amount.
- It uses Dynamic Programming for an efficient solution.
- It measures the execution time of the algorithm.
- It displays the time complexity and space complexity.

**Where:**
- **n** = Number of coin denominations
- **m** = Target amount

## Conclusion
The Dynamic Programming approach efficiently solves the Making Change problem by storing previously computed results. It reduces redundant calculations and finds the minimum number of coins required. The algorithm has a time complexity of **O(n × m)** and a space complexity of **O(m)**, making it suitable for practical applications.