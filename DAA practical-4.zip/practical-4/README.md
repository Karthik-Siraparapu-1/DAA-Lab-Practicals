# Practical 4: Implementation and Time Analysis of Factorial Program

## Aim
To implement the factorial of a number using iterative and recursive methods and compare their execution time, time complexity, and space complexity.

## Summary
- The program calculates the factorial using both iterative and recursive methods.
- It measures the execution time of each method.
- It displays the time complexity and space complexity of both methods.
- Finally, it compares the execution times and indicates which method is faster.

## Conclusion
The iterative and recursive methods both correctly calculate the factorial of a number. Both have a time complexity of **O(n)**, but the iterative method uses **constant space (O(1))**, whereas the recursive method requires **O(n)** space due to the recursion call stack. Therefore, the iterative method is generally more memory-efficient and often executes slightly faster.