# Implementation and Time Analysis of Factorial Program
# Using Iterative and Recursive Methods

import time

# Iterative Method
def factorial_iterative(n):
    fact = 1
    for i in range(1, n + 1):
        fact *= i
    return fact

# Recursive Method
def factorial_recursive(n):
    if n == 0 or n == 1:
        return 1
    return n * factorial_recursive(n - 1)

#  Main Program 

n = int(input("Enter a non-negative integer: "))

if n < 0:
    print("Factorial is not defined for negative numbers.")
else:
    # Measure execution time for Iterative Method
    start = time.perf_counter()
    iterative_result = factorial_iterative(n)
    end = time.perf_counter()
    iterative_time = end - start

    # Measure execution time for Recursive Method
    start = time.perf_counter()
    recursive_result = factorial_recursive(n)
    end = time.perf_counter()
    recursive_time = end - start

    # Display Results
    print("\nFACTORIAL TIME ANALYSIS ")

    print("\nIterative Method")
    print("Factorial        :", iterative_result)
    print(f"Execution Time   : {iterative_time:.10f} seconds")
    print("Time Complexity  : O(n)")
    print("Space Complexity : O(1)")

    print("\nRecursive Method")
    print("Factorial        :", recursive_result)
    print(f"Execution Time   : {recursive_time:.10f} seconds")
    print("Time Complexity  : O(n)")
    print("Space Complexity : O(n)")

    print("\nComparison")
    if iterative_time < recursive_time:
        print("Iterative method is faster.")
    elif recursive_time < iterative_time:
        print("Recursive method is faster.")
    else:
        print("Both methods took approximately the same execution time.")