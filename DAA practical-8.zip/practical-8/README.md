# Practical 8 – Implementation of Graph and Searching (BFS & DFS)

## Aim
To implement a graph using an adjacency list in Python and perform graph traversal using **Breadth First Search (BFS)** and **Depth First Search (DFS)** algorithms. The objective is to understand graph representation and learn different searching techniques used to traverse all the vertices of a graph.

---

## Algorithm for BFS
1. Start the program.
2. Read the number of vertices.
3. Create the graph using an adjacency list.
4. Read the starting vertex.
5. Create an empty queue and an empty visited set.
6. Insert the starting vertex into the queue and mark it as visited.
7. Repeat until the queue becomes empty:
   - Remove the front vertex from the queue.
   - Display the vertex.
   - Visit all its unvisited neighboring vertices.
   - Mark them as visited and insert them into the queue.
8. Stop the program.

---

## Algorithm for DFS
1. Start the program.
2. Read the number of vertices.
3. Create the graph using an adjacency list.
4. Read the starting vertex.
5. Create an empty visited set.
6. Visit the starting vertex and mark it as visited.
7. Display the current vertex.
8. Recursively visit each unvisited neighboring vertex.
9. Continue until all reachable vertices are visited.
10. Stop the program.

---

## Summary
In this practical, a graph was represented using an adjacency list and traversed using **Breadth First Search (BFS)** and **Depth First Search (DFS)**. BFS uses a **queue** to visit vertices level by level, whereas DFS uses **recursion** to explore vertices as deep as possible before backtracking. The traversal starts from a user-specified vertex, and the order of visited vertices is displayed.

---

## Conclusion
The BFS and DFS algorithms were successfully implemented in Python. Both algorithms correctly traversed the graph from the given starting vertex and produced the expected traversal order. This practical enhanced the understanding of graph representation, graph traversal techniques, and the use of queue and recursion in solving graph-related problems.