# Practical 10 - Kruskal's Algorithm

## Aim

To implement Kruskal's Algorithm in Python to find the Minimum Spanning Tree (MST) of a weighted graph.

## Theory

Kruskal's Algorithm is a greedy algorithm that finds the Minimum Spanning Tree by sorting all edges in increasing order of weight and repeatedly selecting the smallest edge that does not form a cycle.

## Requirements

- Python 3.x

## Input

- Number of vertices
- Number of edges
- Edge details in the format:
  ```
  Source Destination Weight
  ```
- Enter values separated by spaces.

## Output

- Edges selected in the Minimum Spanning Tree
- Total minimum cost

## Algorithm

1. Read the number of vertices.
2. Read the number of edges.
3. Store all edges with their weights.
4. Sort the edges in ascending order of weight.
5. Select the smallest edge that does not form a cycle.
6. Repeat until the Minimum Spanning Tree is formed.
7. Display the selected edges and total minimum cost.

## Summary

This program accepts a weighted graph from the user and applies Kruskal's Algorithm to construct the Minimum Spanning Tree by selecting the smallest edges without creating cycles.

## Conclusion

Kruskal's Algorithm efficiently finds the Minimum Spanning Tree by processing edges in increasing order of weight. The program successfully displays the selected edges and computes the total minimum cost.