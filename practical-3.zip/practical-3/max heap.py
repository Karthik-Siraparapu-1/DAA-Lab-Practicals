import time


# Function to heapify a subtree rooted at index i
def heapify(arr, n, i):
    largest = i
    left = 2 * i + 1
    right = 2 * i + 2

    if left < n and arr[left] > arr[largest]:
        largest = left

    if right < n and arr[right] > arr[largest]:
        largest = right

    if largest != i:
        arr[i], arr[largest] = arr[largest], arr[i]
        heapify(arr, n, largest)


# Heap Sort Function
def heap_sort(arr):
    n = len(arr)

    # Build max heap
    for i in range(n // 2 - 1, -1, -1):
        heapify(arr, n, i)

    # Extract elements one by one
    for i in range(n - 1, 0, -1):
        arr[0], arr[i] = arr[i], arr[0]
        heapify(arr, i, 0)


# User input
n = int(input("Enter the number of elements: "))

arr = []

print("Enter the elements:")

for i in range(n):
    element = int(input())
    arr.append(element)

print("\nOriginal Array:", arr)

# Measure execution time
start_time = time.perf_counter()

heap_sort(arr)

end_time = time.perf_counter()

execution_time = end_time - start_time

print("\nSorted Array:", arr)

print("\nExecution Time: {:.10f} seconds".format(execution_time))

# Time complexities
print("\nTime Complexities:")
print("Best Case   : O(n log n)")
print("Average Case: O(n log n)")
print("Worst Case  : O(n log n)")

# Space complexity
print("\nSpace Complexity:")
print("O(1)")