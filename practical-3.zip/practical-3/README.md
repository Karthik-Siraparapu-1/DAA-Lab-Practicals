# Max Heap Sort in Python

## Summary

Max Heap Sort is a sorting algorithm that uses the max heap data structure. In this algorithm, the largest element is placed at the root of the heap and is repeatedly moved to its correct position in the array. The process continues until all elements are sorted.

The program accepts user input, sorts the elements using Heap Sort, and displays the execution time.

## Algorithm

1. Read the number of elements.
2. Accept the array elements from the user.
3. Build a max heap.
4. Swap the root element with the last element.
5. Heapify the remaining elements.
6. Repeat until the array is sorted.
7. Display the sorted array and execution time.

## Time Complexity

- Best Case: O(n log n)
- Average Case: O(n log n)
- Worst Case: O(n log n)

## Space Complexity

- O(1)

## Conclusion

Heap Sort is an efficient sorting algorithm that uses the heap data structure to sort elements. It guarantees a time complexity of O(n log n) in all cases and requires constant extra space, making it suitable for large datasets.